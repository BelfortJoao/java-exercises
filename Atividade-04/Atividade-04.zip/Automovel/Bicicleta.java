/**
 * Bicicleta
 */
public class Bicicleta extends Veiculo {

  public Bicicleta() {
    super();
  }

  public int getNumerodeRodas() {
    return 2;
  }

}
