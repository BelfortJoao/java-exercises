/**
 * Objetc
 */
public interface Objeto {

  public String getTipo();
}
