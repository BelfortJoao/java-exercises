/**
 * Papel
 */
public class Papel implements Objeto {

  public String getTipo() {
    return "Papel";
  }

}
