/**
 * Pedra
 */
public class Pedra implements Objeto {

  public String getTipo() {
    return "Pedra";
  }

}
