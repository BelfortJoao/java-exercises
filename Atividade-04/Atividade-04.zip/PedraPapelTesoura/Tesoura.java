/**
 * Tesoura
 */
public class Tesoura implements Objeto {

  public String getTipo() {
    return "Tesoura";
  }
}
